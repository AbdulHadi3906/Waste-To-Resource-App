package com.yehn.wastetoresourcemanagement;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {
    @SerializedName("Id")
    private int id;

    @SerializedName("Name")
    private String name;

    @SerializedName("Email")
    private String email;

    @SerializedName("Password")
    private String password;

    @SerializedName("Role")
    private String role;

    public int getId() {
        return id;
    }
    public String getName() {return name;}

    // Add other getters as needed
}
