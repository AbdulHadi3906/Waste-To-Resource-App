//package com.yehn.wastetoresourcemanagement;
//import android.content.Context;
//import android.database.sqlite.SQLiteDatabase;
//import android.content.ContentValues;
//import android.database.Cursor;
//import android.database.sqlite.SQLiteOpenHelper;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class DBHelper extends SQLiteOpenHelper {
//
//    public static final String Database_Name = "Swapify";
//    public static final int Database_Version = 3;
//
//    public DBHelper(Context context)
//    {
//        super(context,Database_Name,null,Database_Version);
//    }
//
//    @Override
//    public void onCreate(SQLiteDatabase db) {
//        String createUserTable = "CREATE TABLE user (" +
//                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
//                "name TEXT, " +
//                "email TEXT, " +
//                "password TEXT)";
//
//        String createProductTable = "CREATE TABLE product (" +
//                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
//                "user_id INTEGER, " +
//                "title TEXT, " +
//                "description TEXT, " +
//                "image BLOB, " +
//                "status TEXT DEFAULT 'Available')";
//
//        String createRequestTable = "CREATE TABLE request (" +
//                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
//                "product_id INTEGER, " +
//                "requester_id INTEGER, " +
//                "offered_product_id INTEGER, " +
//                "status TEXT DEFAULT 'Pending')";
//
//
//
//        db.execSQL(createRequestTable);
//        db.execSQL(createProductTable);
//        db.execSQL(createUserTable);
//    }
//
//    public boolean insertUser(String name, String email, String password) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues values = new ContentValues();
//
//        values.put("name", name);
//        values.put("email", email);
//        values.put("password", password);
//
//        if (db.insert("user", null, values) == -1) {
//            return false;
//        } else {
//            return true;
//        }
//    }
//
//    public boolean insertProduct(int userId, String title, String description, byte[] imagebytes) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues values = new ContentValues();
//        values.put("user_id", userId);  // ✅ NEW LINE
//        values.put("title", title);
//        values.put("description", description);
//        values.put("image", imagebytes);
//        values.put("status", "Available");
//        if(db.insert("product", null, values) == -1 )
//        {
//            return false;
//        }
//        else
//        {
//            return true;
//        }
//    }
//
//
//    public boolean checkUser(String email, String password) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor cursor = db.rawQuery("SELECT * FROM user WHERE email=? AND password=?", new String[]{email, password});
//        boolean exists = cursor.getCount() > 0;
//        cursor.close();
//        return exists;
//    }
//
//    public int getUserId(String email) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor cursor = db.rawQuery("SELECT id FROM user WHERE email = ?", new String[]{email});
//        int userId = -1;
//
//        if (cursor.moveToFirst()) {
//            userId = cursor.getInt(0);
//        }
//        cursor.close();
//        return userId;
//    }
//
//    public List<Product> getUserProducts(int userId) {
//        List<Product> productList = new ArrayList<>();
//        SQLiteDatabase db = this.getReadableDatabase();
//
//        Cursor cursor = db.rawQuery("SELECT id, title, description, image FROM product WHERE user_id = ?", new String[]{String.valueOf(userId)});
//
//        if (cursor.moveToFirst()) {
//            do {
//                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
//                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
//                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
//
//                // Read image as stream
//                byte[] image = cursor.getBlob(cursor.getColumnIndexOrThrow("image"));
//
////                productList.add(new Product(id, title, description, image));
//            } while (cursor.moveToNext());
//        }
//
//        cursor.close();
//        return productList;
//    }
//
//
//
//
//    @Override
//    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
//    {
//        db.execSQL("Drop table if exists user");
//        db.execSQL("Drop table if exists product");
//        db.execSQL("Drop table if exists request");
//        onCreate(db);
//    }
//
//    public List<Product> getOtherUsersProducts(int currentUserId) {
//        List<Product> productList = new ArrayList<>();
//        SQLiteDatabase db = this.getReadableDatabase();
//
//        Cursor cursor = db.rawQuery("SELECT * FROM product WHERE user_id != ?", new String[]{String.valueOf(currentUserId)});
//        if (cursor.moveToFirst()) {
//            do {
//                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
//                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
//                String desc = cursor.getString(cursor.getColumnIndexOrThrow("description"));
//                byte[] imageBytes = cursor.getBlob(cursor.getColumnIndexOrThrow("image"));
//                productList.add(new Product(id, title, desc, imageBytes));
//            } while (cursor.moveToNext());
//        }
//        cursor.close();
//        return productList;
//    }
//
//    public boolean insertRequest(int productId, int requesterId, int offeredProductId) {
//        SQLiteDatabase db = this.getWritableDatabase();
//
//        // Check for duplicate request
//        Cursor cursor = db.rawQuery(
//                "SELECT * FROM request WHERE product_id=? AND requester_id=?",
//                new String[]{String.valueOf(productId), String.valueOf(requesterId)}
//        );
//
//        if (cursor.getCount() > 0) {
//            cursor.close();
//            return false;
//        }
//
//        cursor.close();
//
//        ContentValues values = new ContentValues();
//        values.put("product_id", productId);
//        values.put("requester_id", requesterId);
//        values.put("offered_product_id", offeredProductId); // ✅
//        values.put("status", "Pending");
//
//        if  (db.insert("request", null, values) == -1)
//        {
//            return false;
//        }
//        else
//        {
//            return true;
//        }
//    }
//
//    public List<Request> getRequestsForUser(int ownerId) {
//        List<Request> requestList = new ArrayList<>();
//        SQLiteDatabase db = this.getReadableDatabase();
//
//        String query = "SELECT r.id as request_id, r.requester_id, r.status, " +
//                "rp.id as requested_product_id, rp.title as requested_title, rp.description as requested_desc, rp.image as requested_image, " +
//                "op.id as offered_product_id, op.title as offered_title, op.description as offered_desc, op.image as offered_image " +
//                "FROM request r " +
//                "JOIN product rp ON r.product_id = rp.id " +
//                "JOIN product op ON r.offered_product_id = op.id " +
//                "WHERE rp.user_id = ?";
//
//        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(ownerId)});
//
//        if (cursor.moveToFirst()) {
//            do {
//                int requestId = cursor.getInt(cursor.getColumnIndexOrThrow("request_id"));
//                int requesterId = cursor.getInt(cursor.getColumnIndexOrThrow("requester_id"));
//                String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
//
//                // Convert image columns from BLOB to byte[]
//                byte[] requestedImage = cursor.getBlob(cursor.getColumnIndexOrThrow("requested_image"));
//                byte[] offeredImage = cursor.getBlob(cursor.getColumnIndexOrThrow("offered_image"));
//
//                Product requestedProduct = new Product(
//                        cursor.getInt(cursor.getColumnIndexOrThrow("requested_product_id")),
//                        cursor.getString(cursor.getColumnIndexOrThrow("requested_title")),
//                        cursor.getString(cursor.getColumnIndexOrThrow("requested_desc")),
//                        requestedImage
//                );
//
//                Product offeredProduct = new Product(
//                        cursor.getInt(cursor.getColumnIndexOrThrow("offered_product_id")),
//                        cursor.getString(cursor.getColumnIndexOrThrow("offered_title")),
//                        cursor.getString(cursor.getColumnIndexOrThrow("offered_desc")),
//                        offeredImage
//                );
//
//                requestList.add(new Request(requestId, requesterId, requestedProduct, offeredProduct, status));
//
//            } while (cursor.moveToNext());
//        }
//
//        cursor.close();
//        return requestList;
//    }
//
//    public boolean updateRequestStatus(int requestId, String newStatus) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues values = new ContentValues();
//        values.put("status", newStatus);
//
//        int rowsAffected = db.update("request", values, "id = ?", new String[]{String.valueOf(requestId)});
//
//        if (rowsAffected > 0)
//        {
//            return true;
//
//        }
//        else
//        {
//            return  false;
//        }
//    }
//
//
//
//
//
//
//}
