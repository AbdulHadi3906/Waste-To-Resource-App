package com.yehn.wastetoresourcemanagement;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewItemsAdaptor extends RecyclerView.Adapter<ViewItemsAdaptor.ViewHolder> {

    private Context context;
    private List<Product> productList;
    private int userId;

    public ViewItemsAdaptor(Context context, List<Product> productList, int userId) {
        this.context = context;
        this.productList = productList;
        this.userId = userId;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.viewitems, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Product product = productList.get(position);

        holder.itemTitle.setText(product.title);
        holder.itemDescription.setText(product.description);

        if (product.ImageBase64 != null) {
            try {
                byte[] imageBytes = Base64.decode(product.ImageBase64, Base64.DEFAULT);
                holder.itemImage.setImageBitmap(BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Exchange Request
        holder.btnRequest.setOnClickListener(v -> fetchUserProductsToOffer(product));

        // Like Button
        holder.btnLike.setOnClickListener(v -> fetchProductIdAndLike(product, holder));

        // Load Like Count
        updateLikeCount(holder, product);
    }

    private void fetchProductIdAndLike(Product product, ViewHolder holder) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        apiService.getProductId(product.title, product.userId).enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if (response.isSuccessful() && response.body() != null) {
                    int productId = response.body();
                    Like like = new Like(userId,productId);
                    apiService.likeProduct(like).enqueue(new Callback<ResponseBody>() {
                        @Override
                        public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                            if (response.isSuccessful()) {
                                Toast.makeText(context, "Liked!", Toast.LENGTH_SHORT).show();
                                updateLikeCount(holder, product); // refresh like count
                            } else {
                                Toast.makeText(context, "Failed to like", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<ResponseBody> call, Throwable t) {
                            Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(context, "Failed to fetch product ID", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                Toast.makeText(context, "Error fetching product ID", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateLikeCount(ViewHolder holder, Product product) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        apiService.getProductId(product.title, product.userId).enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if (response.isSuccessful() && response.body() != null) {
                    int productId = response.body();

                    apiService.getLikeCount(productId).enqueue(new Callback<Integer>() {
                        @Override
                        public void onResponse(Call<Integer> call, Response<Integer> response) {
                            if (response.isSuccessful() && response.body() != null) {
                                holder.likeCount.setText("❤️ " + response.body());
                            } else {
                                holder.likeCount.setText("❤️ 0");
                            }
                        }

                        @Override
                        public void onFailure(Call<Integer> call, Throwable t) {
                            holder.likeCount.setText("❤️ ?");
                        }
                    });

                } else {
                    holder.likeCount.setText("❤️ ?");
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                holder.likeCount.setText("❤️ ?");
            }
        });
    }

    private void fetchUserProductsToOffer(Product requestedProduct) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        apiService.getUserProducts(userId).enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                    List<Product> userProducts = response.body();

                    BottomSheetDialog dialog = new BottomSheetDialog(context);
                    View sheetView = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_select_product, null);
                    dialog.setContentView(sheetView);

                    RecyclerView recyclerView = sheetView.findViewById(R.id.recycler_exchange_items);
                    recyclerView.setLayoutManager(new LinearLayoutManager(context));

                    ExchangeItemsAdapter adapter = new ExchangeItemsAdapter(context, userProducts, selectedProduct -> {
                        fetchRequestedProductId(requestedProduct, selectedProduct);
                        dialog.dismiss();
                    });

                    recyclerView.setAdapter(adapter);
                    dialog.show();

                } else {
                    Toast.makeText(context, "You don't have any items to offer!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                Toast.makeText(context, "Failed to load your items", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchRequestedProductId(Product requestedProduct, Product offeredProduct) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        apiService.getProductId(requestedProduct.title, requestedProduct.userId).enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if (response.isSuccessful() && response.body() != null) {
                    int requestedProductId = response.body();
                    sendExchangeRequest(requestedProductId, requestedProduct, offeredProduct);
                } else {
                    Toast.makeText(context, "Could not fetch product ID", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendExchangeRequest(int requestedProductId, Product requestedProduct, Product offeredProduct) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        String base64Image = offeredProduct.ImageBase64 != null ? offeredProduct.ImageBase64 : "";

        ExchangeRequest request = new ExchangeRequest(
                requestedProductId,
                offeredProduct.title,
                offeredProduct.description,
                base64Image,
                userId,
                requestedProduct.userId,
                "Pending"
        );

        apiService.submitExchangeRequest(request).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "Exchange request sent!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Failed to send request", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView itemImage;
        TextView itemTitle, itemDescription, likeCount;
        Button btnRequest;
        ImageButton btnLike;

        public ViewHolder(View itemView) {
            super(itemView);
            itemImage = itemView.findViewById(R.id.item_image);
            itemTitle = itemView.findViewById(R.id.item_title);
            itemDescription = itemView.findViewById(R.id.item_description);
            likeCount = itemView.findViewById(R.id.tv_like_count);
            btnRequest = itemView.findViewById(R.id.btn_request);
            btnLike = itemView.findViewById(R.id.btn_like);
        }
    }
}
