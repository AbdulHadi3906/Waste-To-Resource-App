package com.yehn.wastetoresourcemanagement;

public class Like {
    public int UserID;
    public int ProductId;

    public Like(int userID , int ProductId)
    {
        this.UserID = userID;
        this.ProductId = ProductId;
    }

    public int getUserID() {
        return UserID;
    }

    public int getProductId()
    {
        return ProductId;
    }
}
