//package com.yehn.wastetoresourcemanagement;
//
//import android.os.Bundle;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.List;
//
//public class ViewRequestsActivity extends AppCompatActivity {
//
//    RecyclerView recyclerView;
//    RequestAdapter requestAdapter;
//    DBHelper dbHelper;
//    int userId;  // Assume it's passed from previous activity
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_view_requests);
//
//        recyclerView = findViewById(R.id.recycler_view_requests);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//
//        dbHelper = new DBHelper(this);
//        userId = getIntent().getIntExtra("user_id", -1);
//
//        loadRequests();
//    }
//
//    private void loadRequests() {
//        List<Request> requestList = dbHelper.getRequestsForUser(userId);
//        requestAdapter = new RequestAdapter(this, requestList);
//        recyclerView.setAdapter(requestAdapter);
//    }
//}
