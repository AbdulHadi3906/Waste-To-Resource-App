package com.yehn.wastetoresourcemanagement;

public class ExchangeRequest {
    public int ProductId;                 // ID of the requested product
    public String OfferedProductTitle;
    public String OfferedDescription;
    public String OfferedImage;          // base64 string (for JSON, not raw bytes)
    public int RequesterUserId;
    public int OwnerUserId;
    public String Status;

    public ExchangeRequest(int productId, String title, String desc, String imageBase64,
                           int requesterId, int ownerId, String status) {
        this.ProductId = productId;
        this.OfferedProductTitle = title;
        this.OfferedDescription = desc;
        this.OfferedImage = imageBase64;
        this.RequesterUserId = requesterId;
        this.OwnerUserId = ownerId;
        this.Status = status;
    }
}
