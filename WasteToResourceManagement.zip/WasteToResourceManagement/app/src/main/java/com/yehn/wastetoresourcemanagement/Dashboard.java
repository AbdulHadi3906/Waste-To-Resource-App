package com.yehn.wastetoresourcemanagement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_products);

        CardView btn_add = findViewById(R.id.card_add_item);
        CardView btn_view_items = findViewById(R.id.card_view_items);
        CardView btn_my_items = findViewById(R.id.card_my_items);
        CardView btn_requests = findViewById(R.id.card_requests);
        TextView user_name = findViewById(R.id.tv_username);

        int userId = getIntent().getIntExtra("user_id", -1);
        String username = getIntent().getStringExtra("name");

        user_name.setText(username);

        btn_add.setOnClickListener(v -> {
            Intent addIntent = new Intent(Dashboard.this, AddItem.class);
            addIntent.putExtra("user_id", userId);
            startActivity(addIntent);
        });

        btn_view_items.setOnClickListener(v -> {
            Intent viewIntent = new Intent(Dashboard.this, ViewItemsActivity.class);
            viewIntent.putExtra("user_id", userId);
            startActivity(viewIntent);
        });
//
        btn_my_items.setOnClickListener(v -> {
            Intent addIntent = new Intent(Dashboard.this, MyItems.class);
            addIntent.putExtra("user_id", userId);
            startActivity(addIntent);
        });
//////
//        btn_requests.setOnClickListener(v -> {
//            Intent intent = new Intent(Dashboard.this,ViewRequestsActivity.class);
//            intent.putExtra("user_id", userId);
//            startActivity(intent);
//        });
    }
}