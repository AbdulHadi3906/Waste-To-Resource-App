//package com.yehn.wastetoresourcemanagement;
//
//import android.content.Context;
//import android.graphics.BitmapFactory;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.List;
//
//class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.ViewHolder> {
//
//    private Context context;
//    private List<Request> requestList;
//    private DBHelper dbHelper;
//
//    public RequestAdapter(Context context, List<Request> requestList) {
//        this.context = context;
//        this.requestList = requestList;
//        dbHelper = new DBHelper(context);
//    }
//
//    public static class ViewHolder extends RecyclerView.ViewHolder {
//        ImageView requestedImage, offeredImage;
//        TextView requestedTitle, requestedDescription;
//        TextView offeredTitle, offeredDescription;
//        TextView statusText;
//        Button btnAccept, btnReject;
//
//        public ViewHolder(View itemView) {
//            super(itemView);
//            requestedImage = itemView.findViewById(R.id.requested_image);
//            offeredImage = itemView.findViewById(R.id.offered_image);
//            requestedTitle = itemView.findViewById(R.id.requested_title);
//            requestedDescription = itemView.findViewById(R.id.requested_description);
//            offeredTitle = itemView.findViewById(R.id.offered_title);
//            offeredDescription = itemView.findViewById(R.id.offered_description);
//            statusText = itemView.findViewById(R.id.request_status);
//            btnAccept = itemView.findViewById(R.id.btn_accept);
//            btnReject = itemView.findViewById(R.id.btn_reject);
//        }
//    }
//
//    @Override
//    public RequestAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_request, parent, false);
//        return new ViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(RequestAdapter.ViewHolder holder, int position) {
//        Request request = requestList.get(position);
//
//        // Set product info
//        holder.requestedTitle.setText(request.requestedProduct.title);
//        holder.requestedDescription.setText(request.requestedProduct.description);
//
//        holder.offeredTitle.setText(request.offeredProduct.title);
//        holder.offeredDescription.setText(request.offeredProduct.description);
//
//        // Set images from byte[]
//        holder.requestedImage.setImageBitmap(BitmapFactory.decodeByteArray(
//                request.requestedProduct.imageUri, 0, request.requestedProduct.imageUri.length));
//
//        holder.offeredImage.setImageBitmap(BitmapFactory.decodeByteArray(
//                request.offeredProduct.imageUri, 0, request.offeredProduct.imageUri.length));
//
//        // Set current status
//        holder.statusText.setText("Status: " + request.status);
//
//// Accept button click
//        holder.btnAccept.setOnClickListener(v -> {
//            boolean updated = dbHelper.updateRequestStatus(request.id, "Accepted");
//            if (updated) {
//                Toast.makeText(context, "Request Accepted", Toast.LENGTH_SHORT).show();
//                requestList.remove(position); // ✅ Remove from list
//                notifyItemRemoved(position);  // ✅ Notify adapter
//                notifyItemRangeChanged(position, requestList.size());
//            }
//        });
//
//// Reject button click
//        holder.btnReject.setOnClickListener(v -> {
//            boolean updated = dbHelper.updateRequestStatus(request.id, "Rejected");
//            if (updated) {
//                Toast.makeText(context, "Request Rejected", Toast.LENGTH_SHORT).show();
//                requestList.remove(position); // ✅ Remove from list
//                notifyItemRemoved(position);  // ✅ Notify adapter
//                notifyItemRangeChanged(position, requestList.size());
//            }
//        });
//
//    }
//
//    @Override
//    public int getItemCount() {
//        return requestList.size();
//    }
//}
