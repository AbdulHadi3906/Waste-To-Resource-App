package com.yehn.wastetoresourcemanagement;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ExchangeItemsAdapter extends RecyclerView.Adapter<ExchangeItemsAdapter.ViewHolder> {

    private Context context;
    private List<Product> productList;
    private OnProductSelectedListener listener;

    public interface OnProductSelectedListener {
        void onProductSelected(Product offeredProduct);
    }

    public ExchangeItemsAdapter(Context context, List<Product> productList, OnProductSelectedListener listener) {
        this.context = context;
        this.productList = productList;
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView title, description;
        Button offerButton;

        public ViewHolder(View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.item_image);
            title = itemView.findViewById(R.id.item_title);
            description = itemView.findViewById(R.id.item_description);
            offerButton = itemView.findViewById(R.id.btn_offer);
        }
    }

    @Override
    public ExchangeItemsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_offer_product, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ExchangeItemsAdapter.ViewHolder holder, int position) {
        Product product = productList.get(position);

        holder.title.setText(product.title);
        holder.description.setText(product.description);

        if (product.ImageBase64 != null && !product.ImageBase64.isEmpty()) {
            try {
                byte[] imageBytes = Base64.decode(product.ImageBase64, Base64.DEFAULT);
                holder.image.setImageBitmap(BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            holder.image.setImageResource(R.drawable.default_image); // fallback image
        }

        holder.offerButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onProductSelected(product);
            }
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }
}
