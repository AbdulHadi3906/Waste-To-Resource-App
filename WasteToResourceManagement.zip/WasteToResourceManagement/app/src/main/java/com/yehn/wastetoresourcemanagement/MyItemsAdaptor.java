package com.yehn.wastetoresourcemanagement;

import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;
import android.content.Context;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

class MyItemsAdapter extends RecyclerView.Adapter<MyItemsAdapter.ViewHolder> {

    private Context context;
    private List<Product> productList;

    public MyItemsAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
    }

    @Override
    public MyItemsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_my_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyItemsAdapter.ViewHolder holder, int position) {
        Product product = productList.get(position);
        holder.itemTitle.setText(product.title);
        holder.itemDescription.setText(product.description);

        if (product.ImageBase64 != null && !product.ImageBase64.isEmpty()) {
            try {
                byte[] imageBytes = Base64.decode(product.ImageBase64, Base64.DEFAULT);
                holder.itemImage.setImageBitmap(BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            holder.itemImage.setImageResource(R.drawable.default_image); // fallback
        }
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView itemImage;
        TextView itemTitle, itemDescription;

        public ViewHolder(View itemView) {
            super(itemView);
            itemImage = itemView.findViewById(R.id.item_image);
            itemTitle = itemView.findViewById(R.id.item_title);
            itemDescription = itemView.findViewById(R.id.item_description);
        }
    }
}
