package com.yehn.wastetoresourcemanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminDashboard extends AppCompatActivity {

    TextView usersCount, listingsCount, exchangeCount;
    Button btnRegisterAdmin, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        // 🔁 Bind UI elements
        usersCount = findViewById(R.id.UsersCount);
        listingsCount = findViewById(R.id.listingscount);
        exchangeCount = findViewById(R.id.exchangeCount);
        btnRegisterAdmin = findViewById(R.id.btnRegisterAdmin);
        btnLogout = findViewById(R.id.btnLogout);

        // 🔁 Load counts from API
        loadDashboardStats();

        // 🟢 Register Admin click
        btnRegisterAdmin.setOnClickListener(v -> {
            startActivity(new Intent(this, AdminRegistration.class));
        });

        // 🔴 Logout click
        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(this, Login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadDashboardStats() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        // 🟢 Total Users
        apiService.getTotalUsers().enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if (response.isSuccessful()) {
                    usersCount.setText(String.valueOf(response.body()));
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                Toast.makeText(AdminDashboard.this, "Failed to load users count", Toast.LENGTH_SHORT).show();
            }
        });

        // 🟢 Total Products
        apiService.getTotalProducts().enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if (response.isSuccessful()) {
                    listingsCount.setText(String.valueOf(response.body()));
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                Toast.makeText(AdminDashboard.this, "Failed to load listings count", Toast.LENGTH_SHORT).show();
            }
        });

        // 🟢 Total Exchanges
        apiService.getTotalExchanges().enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if (response.isSuccessful()) {
                    exchangeCount.setText(String.valueOf(response.body()));
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                Toast.makeText(AdminDashboard.this, "Failed to load exchanges count", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
