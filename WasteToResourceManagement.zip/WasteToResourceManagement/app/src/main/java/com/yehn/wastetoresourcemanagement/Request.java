package com.yehn.wastetoresourcemanagement;

public class Request {
    public int id;
    public int requesterId;
    public Product requestedProduct;
    public Product offeredProduct;
    public String status;

    public Request(int id, int requesterId, Product requestedProduct, Product offeredProduct, String status) {
        this.id = id;
        this.requesterId = requesterId;
        this.requestedProduct = requestedProduct;
        this.offeredProduct = offeredProduct;
        this.status = status;
    }
}
