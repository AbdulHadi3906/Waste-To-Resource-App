package com.yehn.wastetoresourcemanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import com.google.android.material.textfield.TextInputEditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminRegistration extends AppCompatActivity {

    TextView txtName, txtEmail, txtPassword, errorMessage;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_registration);

        txtName = findViewById(R.id.txt_name);
        txtEmail = findViewById(R.id.txt_email);
        txtPassword = findViewById(R.id.txt_password);
        errorMessage = findViewById(R.id.errormessage);
        btnSubmit = findViewById(R.id.btnLogin);

        btnSubmit.setOnClickListener(v -> {
            String name = txtName.getText().toString().trim();
            String email = txtEmail.getText().toString().trim();
            String password = txtPassword.getText().toString().trim();
            String role = "admin";

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }



            RegisterRequest request = new RegisterRequest(name, email, password,role);
            ApiService apiService = ApiClient.getClient().create(ApiService.class);

            Call<RegisterResponse> call = apiService.registerAdmin(request);
            call.enqueue(new Callback<RegisterResponse>() {
                @Override
                public void onResponse(Call<RegisterResponse> call, Response<RegisterResponse> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(AdminRegistration.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(AdminRegistration.this, AdminLogin.class));
                    } else {
                        // Show actual error code and body
                        Toast.makeText(AdminRegistration.this, "Error: " + response.code(), Toast.LENGTH_LONG).show();
                        try {
                            Log.e("API_RESPONSE_ERROR", response.errorBody().string());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }


                @Override
                public void onFailure(Call<RegisterResponse> call, Throwable t) {
                    errorMessage.setText("Failed: " + t.getMessage());
                    errorMessage.setVisibility(View.VISIBLE);
                    t.printStackTrace();  // Add this line to print full error in Logcat
                }

            });
        });
    }
}
