package com.yehn.wastetoresourcemanagement;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        EditText txtemail = findViewById(R.id.txt_email);
        EditText txtpassword = findViewById(R.id.txt_password);
        Button login = findViewById(R.id.btnLogin);
        TextView errormessage = findViewById(R.id.errormessage);

        login.setOnClickListener(v -> {
            String email = txtemail.getText().toString().trim();
            String password = txtpassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                errormessage.setText("Please fill all fields");
                errormessage.setVisibility(View.VISIBLE);
                return;
            }

            LoginRequest request = new LoginRequest(email, password, "Admin");
            ApiService apiService = ApiClient.getClient().create(ApiService.class);
            Call<LoginResponse> call = apiService.loginAdmin(request);

            call.enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        // ✅ Admin login successful
                        int adminId = response.body().getId();
                        Intent intent = new Intent(AdminLogin.this, AdminDashboard.class);
                        intent.putExtra("admin_id", adminId);
                        startActivity(intent);
                    } else {
                        errormessage.setText("Invalid credentials for Admin.");
                        errormessage.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    errormessage.setText("Network error: " + t.getMessage());
                    errormessage.setVisibility(View.VISIBLE);
                }
            });
        });
    }
}
