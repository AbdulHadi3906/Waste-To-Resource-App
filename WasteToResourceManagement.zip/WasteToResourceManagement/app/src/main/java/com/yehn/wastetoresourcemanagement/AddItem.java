package com.yehn.wastetoresourcemanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddItem extends AppCompatActivity {

    private static final int IMAGE_PICK_CODE = 1000;

    Uri imageUri;
    ImageView productImage;
    TextInputEditText txtTitle, txtDescription;
    ProgressBar loading;
    Button btnSelectImage, btnSubmit;

    byte[] imageBytes = null;
    int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        txtTitle = findViewById(R.id.txt_title);
        txtDescription = findViewById(R.id.txt_description);
        productImage = findViewById(R.id.product_image);
        btnSelectImage = findViewById(R.id.btn_select_image);
        btnSubmit = findViewById(R.id.btn_submit);
        loading = findViewById(R.id.loading);

        userId = getIntent().getIntExtra("user_id", -1);

        btnSelectImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, IMAGE_PICK_CODE);
        });

        btnSubmit.setOnClickListener(v -> {
            String title = txtTitle.getText().toString().trim();
            String description = txtDescription.getText().toString().trim();

            if (title.isEmpty() || imageBytes == null) {
                Toast.makeText(this, "Please fill all fields and select an image", Toast.LENGTH_SHORT).show();
                return;
            }

            loading.setVisibility(ProgressBar.VISIBLE);
            String base64Image =  Base64.encodeToString(imageBytes, Base64.NO_WRAP);
            // 🧠 Construct Product object to send
            Product product = new Product(title, userId, description, base64Image, "Available");

            ApiService apiService = ApiClient.getClient().create(ApiService.class);
            Call<Void> call = apiService.addProduct(product);

            call.enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    loading.setVisibility(ProgressBar.GONE);
                    if (response.isSuccessful()) {
                        Toast.makeText(AddItem.this, "Product added successfully!", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(AddItem.this, "Failed! Code: " + response.code(), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    loading.setVisibility(ProgressBar.GONE);
                    Toast.makeText(AddItem.this, "Error: " + t.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == IMAGE_PICK_CODE && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();
            productImage.setImageURI(imageUri);
            imageBytes = getBytesFromUri(imageUri);
        }
    }

    private byte[] getBytesFromUri(Uri uri) {
        try (InputStream inputStream = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {

            int nRead;
            byte[] data = new byte[4096];
            while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }

            return buffer.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
