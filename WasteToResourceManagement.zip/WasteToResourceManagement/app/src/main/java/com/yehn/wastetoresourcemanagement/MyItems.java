package com.yehn.wastetoresourcemanagement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.content.Intent;
import android.util.Base64;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyItems extends AppCompatActivity {

    RecyclerView recyclerView;
    MyItemsAdapter adapter;
    int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_items);

        recyclerView = findViewById(R.id.recycler_my_items);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        userId = getIntent().getIntExtra("user_id", -1);

        if (userId != -1) {
            fetchUserProductsFromApi();
        }
    }

    private void fetchUserProductsFromApi() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<List<Product>> call = apiService.getAllProducts();

        call.enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Product> allProducts = response.body();
                    List<Product> userProducts = new ArrayList<>();

                    for (Product p : allProducts) {
                        if (p.userId == userId) {
                            userProducts.add(p);
                        }
                    }

                    adapter = new MyItemsAdapter(MyItems.this, userProducts);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(MyItems.this, "Failed to load items: " + response.code(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                Toast.makeText(MyItems.this, "Error: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
