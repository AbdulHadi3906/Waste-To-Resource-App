package com.yehn.wastetoresourcemanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        EditText txtemail = findViewById(R.id.txt_email);
        EditText txtpassword = findViewById(R.id.txt_password);

        Button btnlogin = findViewById(R.id.btnLogin);
        Button btnRegister = findViewById(R.id.btn_Register);
        Button btnAdmin = findViewById(R.id.btnAdmin);
        TextView errormessage = findViewById(R.id.errormessage);

        btnlogin.setOnClickListener(v -> {
            String email = txtemail.getText().toString().trim();
            String password = txtpassword.getText().toString().trim();
            String role = "user";

            if (email.isEmpty() || password.isEmpty()) {
                errormessage.setText("Please enter email and password");
                errormessage.setVisibility(View.VISIBLE);
                return;
            }

            LoginRequest loginRequest = new LoginRequest(email, password, role);
            ApiService apiService = ApiClient.getClient().create(ApiService.class);

            Call<LoginResponse> call = apiService.loginUser(loginRequest);
            call.enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        LoginResponse loginResponse = response.body();

                        // ✅ Extract user ID from response and proceed
                        int userId = loginResponse.getId();
                        String name = loginResponse.getName();

                        Intent intent = new Intent(Login.this, Dashboard.class);
                        intent.putExtra("user_id", userId);
                        intent.putExtra("name" , name);
                        startActivity(intent);
                        finish();
                    } else {
                        errormessage.setText("Invalid email or password");
                        errormessage.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    errormessage.setText("Network error: " + t.getMessage());
                    errormessage.setVisibility(View.VISIBLE);
                }
            });
        });

        btnRegister.setOnClickListener(v -> {
            Intent intent = new Intent(Login.this, Registration.class);
            startActivity(intent);
        });

        btnAdmin.setOnClickListener(v -> {
            Intent intent = new Intent(Login.this, AdminLogin.class);
            startActivity(intent);
        });
    }
}
