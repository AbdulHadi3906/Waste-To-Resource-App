package com.yehn.wastetoresourcemanagement;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {

    @Headers("Content-Type: application/json")
    @POST("api/user/login")  // ✅ fixed
    Call<LoginResponse> loginUser(@Body LoginRequest loginRequest);

    @Headers("Content-Type: application/json")
    @POST("api/user/register")  // ✅ fixed
    Call<RegisterResponse> registerUser(@Body RegisterRequest request);

    @Headers("Content-Type: application/json")
    @POST("api/admin/login")
    Call<LoginResponse> loginAdmin(@Body LoginRequest request);

    @Headers("Content-Type: application/json")
    @POST("api/admin/register")
    Call<RegisterResponse> registerAdmin(@Body RegisterRequest request);

    @Headers("Content-Type: application/json")
    @POST("api/user/products")
    Call<Void> addProduct(@Body Product product);

    @GET("api/user/product-id")
    Call<Integer> getProductId(
            @Query("title") String title,
            @Query("ownerUserId") int ownerUserId
    );




    @Headers("Content-Type: application/json")
    @POST("api/user/like")
    Call<ResponseBody> likeProduct(@Body Like like);


    @GET("api/like/count")
    Call<Integer> getLikeCount(@Query("productId") int productId);



    @GET("api/user/products")
    Call<List<Product>> getAllProducts();

    @GET("api/products/user/{userId}")
    Call<List<Product>> getUserProducts(@Path("userId") int userId);


    @GET("api/products/others/{userId}")
    Call<List<Product>> getOtherUsersProducts(@Path("userId") int userId);

    @POST("api/user/exchange-requests")
    Call<Void> submitExchangeRequest(@Body ExchangeRequest request);



    @GET("api/admin/total-users")
    Call<Integer> getTotalUsers();

    @GET("api/admin/total-products")
    Call<Integer> getTotalProducts();

    @GET("api/admin/total-exchanges")
    Call<Integer> getTotalExchanges();



}
