package com.yehn.wastetoresourcemanagement;

import com.google.gson.annotations.SerializedName;

public class RegisterRequest {
    @SerializedName("Name")
    private String name;

    @SerializedName("Email")
    private String email;

    @SerializedName("Password")
    private String password;

    @SerializedName("Role")
    private String role;

    public RegisterRequest(String name, String email, String password, String role) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }
}
