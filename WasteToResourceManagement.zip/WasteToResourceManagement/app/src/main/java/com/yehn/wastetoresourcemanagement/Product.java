package com.yehn.wastetoresourcemanagement;

import com.google.gson.annotations.SerializedName;

public class Product {


        @SerializedName("ProductTitle")
        public String title;

        @SerializedName("UserId")
        public int userId;

        @SerializedName("Description")
        public String description;

        @SerializedName("Image")
        public String ImageBase64;

        @SerializedName("Status")
        public String status;

    public Product(String title, int userId, String description, String ImageBase64, String status) {
        this.title = title;
        this.userId = userId;
        this.description = description;
        this.ImageBase64 = ImageBase64;
        this.status = status;
    }

}
